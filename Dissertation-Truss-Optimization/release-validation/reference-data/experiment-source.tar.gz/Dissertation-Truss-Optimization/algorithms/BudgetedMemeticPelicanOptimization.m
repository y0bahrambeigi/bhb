function [bestSol, bestFit, convergence, details] = BudgetedMemeticPelicanOptimization(problem, params)
%BudgetedMemeticPelicanOptimization Equal-FE-budget POA / POA+LS runner.
% Setting params.localSearchTrials = 0 reproduces the budgeted POA baseline.
% Positive localSearchTrials enables a problem-aware elite local search while
% keeping the same total number of structural evaluations.

if nargin < 2, params = struct(); end
if ~isfield(params, 'popSize'), params.popSize = 70; end
if ~isfield(params, 'maxEvaluations'), params.maxEvaluations = 35070; end
if ~isfield(params, 'penaltyCoef'), params.penaltyCoef = 1e7; end
if ~isfield(params, 'levyScale'), params.levyScale = 0.015; end
if ~isfield(params, 'localSearchTrials'), params.localSearchTrials = 0; end
if ~isfield(params, 'qioTrials'), params.qioTrials = 0; end
if ~isfield(params, 'areaMoveProbability'), params.areaMoveProbability = 0.80; end
if ~isfield(params, 'shrinkProbability'), params.shrinkProbability = 0.65; end
if ~isfield(params, 'localSearchMinScale'), params.localSearchMinScale = 0.01; end
if ~isfield(params, 'localSearchMaxScale'), params.localSearchMaxScale = 0.05; end
if ~isfield(params, 'restartFraction'), params.restartFraction = 0.0; end
if ~isfield(params, 'stagnationEvaluations')
    params.stagnationEvaluations = max(params.popSize, round(0.06 * params.maxEvaluations));
end

validateattributes(params.popSize, {'numeric'}, {'scalar','integer','>=',2});
validateattributes(params.maxEvaluations, {'numeric'}, {'scalar','integer','>=',params.popSize});
validateattributes(params.localSearchTrials, {'numeric'}, {'scalar','integer','nonnegative'});
validateattributes(params.qioTrials, {'numeric'}, {'scalar','integer','nonnegative'});
validateattributes(params.restartFraction, {'numeric'}, {'scalar','real','finite','>=',0,'<',1});
validateattributes(params.stagnationEvaluations, {'numeric'}, {'scalar','integer','nonnegative'});

bounds = problem.getBounds();
nVar = problem.nVar;

pelicans = repmat(bounds.lb, params.popSize, 1) + ...
    rand(params.popSize, nVar) .* repmat(bounds.ub - bounds.lb, params.popSize, 1);

topologyIdx = [];
areaIdx = 1:nVar;
isMixedTopology = isprop(problem, 'nBar') && nVar == 2 * problem.nBar;
isDiscreteSizing = isprop(problem, 'decisionType') && ...
    strcmpi(problem.decisionType, 'discrete');
if isMixedTopology
    areaIdx = 1:problem.nBar;
    topologyIdx = (problem.nBar + 1):nVar;
end
if params.qioTrials > 0 && (~isDiscreteSizing || isMixedTopology)
    error('BudgetedMemeticPelicanOptimization:QIODiscreteOnly', ...
        'qioTrials currently supports pure discrete-sizing problems only.');
end

pelicans(1, areaIdx) = 0.5 * (bounds.lb(areaIdx) + bounds.ub(areaIdx));
if ~isempty(topologyIdx), pelicans(1, topologyIdx) = 1; end
if params.popSize >= 2, pelicans(2, :) = bounds.ub; end

if ismethod(problem, 'projectDecision')
    for i = 1:params.popSize
        pelicans(i, :) = problem.projectDecision(pelicans(i, :));
    end
end

fitness = zeros(params.popSize, 1);
objectiveValues = zeros(params.popSize, 1);
violationValues = zeros(params.popSize, 1);
populationInfo = cell(params.popSize, 1);
evaluationCount = 0;
loadCaseSolveCount = 0;
modalSolveCount = 0;
localSearchAttempts = 0;
localSearchAccepted = 0;
qioAttempts = 0;
qioAccepted = 0;
for i = 1:params.popSize
    [f, g, candidateInfo] = problem.evaluate(pelicans(i, :));
    evaluationCount = evaluationCount + 1;
    loadCaseSolveCount = loadCaseSolveCount + localLoadCaseCount(candidateInfo);
    modalSolveCount = modalSolveCount + localModalSolveCount(candidateInfo);
    fitness(i) = f + params.penaltyCoef * g;
    objectiveValues(i) = f;
    violationValues(i) = g;
    populationInfo{i} = candidateInfo;
end

[bestFit, bestIdx] = min(fitness);
bestSol = pelicans(bestIdx, :);
bestObjective = objectiveValues(bestIdx);
bestViolation = violationValues(bestIdx);
bestInfo = populationInfo{bestIdx};
lastImprovementEvaluation = evaluationCount;
restartCount = 0;
restartEvaluationHistory = [];

convergence = [];
evaluationHistory = [];
iteration = 0;

while evaluationCount < params.maxEvaluations
    iteration = iteration + 1;
    progress = min(1, evaluationCount / params.maxEvaluations);
    huntFactor = 2.0 * (1 - progress);
    diveFactor = 0.2 + 0.8 * progress;
    meanPelican = mean(pelicans, 1);

    for i = 1:params.popSize
        if evaluationCount >= params.maxEvaluations, break; end

        Xi = pelicans(i, :);
        if rand < 0.5
            r1 = rand(1, nVar);
            r2 = rand(1, nVar);
            candidate = Xi + huntFactor * ...
                (r1 .* (bestSol - Xi) + r2 .* (meanPelican - Xi));
        else
            localPerturb = randn(1, nVar) .* ...
                (bounds.ub - bounds.lb) * params.levyScale;
            candidate = bestSol + diveFactor * (Xi - bestSol) .* ...
                rand(1, nVar) + localPerturb;
        end

        if ~isempty(topologyIdx)
            flipMask = rand(1, numel(topologyIdx)) < (0.15 * (1 - progress));
            candidate(topologyIdx(flipMask)) = 1 - candidate(topologyIdx(flipMask));
        end

        candidate = max(bounds.lb, min(bounds.ub, candidate));
        if ismethod(problem, 'projectDecision')
            candidate = problem.projectDecision(candidate);
        end

        [candF, candG, candInfo] = problem.evaluate(candidate);
        evaluationCount = evaluationCount + 1;
        loadCaseSolveCount = loadCaseSolveCount + localLoadCaseCount(candInfo);
        modalSolveCount = modalSolveCount + localModalSolveCount(candInfo);
        candFit = candF + params.penaltyCoef * candG;

        if candFit < fitness(i)
            pelicans(i, :) = candidate;
            fitness(i) = candFit;
            objectiveValues(i) = candF;
            violationValues(i) = candG;
            populationInfo{i} = candInfo;
            if candFit < bestFit
                bestFit = candFit;
                bestSol = candidate;
                bestObjective = candF;
                bestViolation = candG;
                bestInfo = candInfo;
                lastImprovementEvaluation = evaluationCount;
            end
        end
    end

    for trial = 1:params.localSearchTrials
        if evaluationCount >= params.maxEvaluations, break; end

        candidate = bestSol;

        if isDiscreteSizing && ~isMixedTopology
            % Discrete/grouped sizing: one-step catalog neighborhood.
            j = randi(nVar);
            if rand < 0.5, step = -1; else, step = 1; end
            candidate(j) = candidate(j) + step;
            candidate = problem.projectDecision(candidate);

        elseif isMixedTopology
            % Mixed sizing/topology benchmark: local coordinate search.
            if rand < params.areaMoveProbability
                j = randi(problem.nBar);
                if rand < params.shrinkProbability
                    direction = -1;
                else
                    direction = 1;
                end
                scale = params.localSearchMinScale + ...
                    (params.localSearchMaxScale - params.localSearchMinScale) * rand;
                candidate(j) = candidate(j) + direction * scale * ...
                    (bounds.ub(j) - bounds.lb(j));
            else
                j = problem.nBar + randi(problem.nBar);
                candidate(j) = 1 - candidate(j);
            end
            candidate = max(bounds.lb, min(bounds.ub, candidate));

        else
            % Generic continuous fallback.
            j = randi(nVar);
            step = (2 * rand - 1) * params.localSearchMaxScale * ...
                (bounds.ub(j) - bounds.lb(j));
            candidate(j) = candidate(j) + step;
            candidate = max(bounds.lb, min(bounds.ub, candidate));
        end

        localSearchAttempts = localSearchAttempts + 1;
        [candF, candG, candInfo] = problem.evaluate(candidate);
        evaluationCount = evaluationCount + 1;
        loadCaseSolveCount = loadCaseSolveCount + localLoadCaseCount(candInfo);
        modalSolveCount = modalSolveCount + localModalSolveCount(candInfo);
        candFit = candF + params.penaltyCoef * candG;

        if candFit < bestFit
            localSearchAccepted = localSearchAccepted + 1;
            bestFit = candFit;
            bestSol = candidate;
            bestObjective = candF;
            bestViolation = candG;
            bestInfo = candInfo;
            lastImprovementEvaluation = evaluationCount;
            [~, worstIdx] = max(fitness);
            pelicans(worstIdx, :) = candidate;
            fitness(worstIdx) = candFit;
            objectiveValues(worstIdx) = candF;
            violationValues(worstIdx) = candG;
            populationInfo{worstIdx} = candInfo;
        end
    end

    % Coordinate-wise quadratic interpolation around the current elite.
    % Each QIO proposal consumes one evaluator call from the same finite
    % structural-analysis budget as the baseline and local-search variants.
    for trial = 1:params.qioTrials
        if evaluationCount >= params.maxEvaluations, break; end

        candidate = localQuadraticCandidate( ...
            bestSol, bestFit, pelicans, fitness, bounds, problem);
        qioAttempts = qioAttempts + 1;

        [candF, candG, candInfo] = problem.evaluate(candidate);
        evaluationCount = evaluationCount + 1;
        loadCaseSolveCount = loadCaseSolveCount + localLoadCaseCount(candInfo);
        modalSolveCount = modalSolveCount + localModalSolveCount(candInfo);
        candFit = candF + params.penaltyCoef * candG;

        [worstFit, worstIdx] = max(fitness);
        if candFit < worstFit
            pelicans(worstIdx, :) = candidate;
            fitness(worstIdx) = candFit;
            objectiveValues(worstIdx) = candF;
            violationValues(worstIdx) = candG;
            populationInfo{worstIdx} = candInfo;
            qioAccepted = qioAccepted + 1;
        end

        if candFit < bestFit
            bestFit = candFit;
            bestSol = candidate;
            bestObjective = candF;
            bestViolation = candG;
            bestInfo = candInfo;
            lastImprovementEvaluation = evaluationCount;
        end
    end

    % Stagnation-triggered diversity restart. Restart evaluations consume the
    % same finite-element budget, so restart variants remain directly comparable.
    if params.restartFraction > 0 && ...
            (evaluationCount - lastImprovementEvaluation) >= params.stagnationEvaluations
        nRestart = max(1, round(params.restartFraction * params.popSize));
        [~, order] = sort(fitness, 'descend');
        restartIdx = order(1:min(nRestart, numel(order)));

        for k = 1:numel(restartIdx)
            if evaluationCount >= params.maxEvaluations, break; end
            idx = restartIdx(k);
            candidate = bounds.lb + rand(1, nVar) .* (bounds.ub - bounds.lb);
            if ismethod(problem, 'projectDecision')
                candidate = problem.projectDecision(candidate);
            end

            [candF, candG, candInfo] = problem.evaluate(candidate);
            evaluationCount = evaluationCount + 1;
            loadCaseSolveCount = loadCaseSolveCount + localLoadCaseCount(candInfo);
        modalSolveCount = modalSolveCount + localModalSolveCount(candInfo);
            candFit = candF + params.penaltyCoef * candG;

            % Replace unconditionally to inject diversity; the elite is protected
            % because only the current worst population members are restarted.
            pelicans(idx, :) = candidate;
            fitness(idx) = candFit;
            objectiveValues(idx) = candF;
            violationValues(idx) = candG;
            populationInfo{idx} = candInfo;
            if candFit < bestFit
                bestFit = candFit;
                bestSol = candidate;
                bestObjective = candF;
                bestViolation = candG;
                bestInfo = candInfo;
            end
        end

        restartCount = restartCount + 1;
        restartEvaluationHistory(end + 1, 1) = evaluationCount; %#ok<AGROW>
        lastImprovementEvaluation = evaluationCount;
    end

    convergence(end + 1, 1) = bestFit; %#ok<AGROW>
    evaluationHistory(end + 1, 1) = evaluationCount; %#ok<AGROW>
end

details.objective = bestObjective;
details.constraintViolation = bestViolation;
details.info = bestInfo;
details.evaluationCount = evaluationCount;
details.evaluatorCalls = evaluationCount;
details.loadCaseSolves = loadCaseSolveCount;
details.modalSolves = modalSolveCount;
details.localSearchAttempts = localSearchAttempts;
details.localSearchAccepted = localSearchAccepted;
details.qioAttempts = qioAttempts;
details.qioAccepted = qioAccepted;
details.iterationsCompleted = iteration;
details.evaluationHistory = evaluationHistory;
details.restartCount = restartCount;
details.restartEvaluationHistory = restartEvaluationHistory;
details.isFeasible = bestInfo.isFeasible;
details.parameters = params;
end

function n = localLoadCaseCount(info)
% One evaluator call may solve several independent load cases.
if isfield(info, 'nLoadCases')
    n = info.nLoadCases;
elseif isfield(info, 'loads') && ~isempty(info.loads)
    n = size(info.loads, 2);
else
    n = 1;
end
end


function n = localModalSolveCount(info)
if isfield(info, 'modalAnalysisPerformed') && info.modalAnalysisPerformed
    n = 1;
else
    n = 0;
end
end

function candidate = localQuadraticCandidate(bestSol, bestFit, population, fitness, bounds, problem)
% Fit a one-dimensional parabola through the elite and two population
% samples for one randomly selected coordinate. Degenerate interpolation
% falls back to a one-catalog-step move before projection.

nVar = numel(bestSol);
j = randi(nVar);
nPop = size(population,1);
candidate = bestSol;

if nPop < 2
    step = 2*(rand >= 0.5)-1;
    candidate(j) = candidate(j) + step;
else
    pick = randperm(nPop,2);
    x1 = bestSol(j); f1 = bestFit;
    x2 = population(pick(1),j); f2 = fitness(pick(1));
    x3 = population(pick(2),j); f3 = fitness(pick(2));

    denom = 2*((x2-x3)*f1 + (x3-x1)*f2 + (x1-x2)*f3);
    numer = (x2^2-x3^2)*f1 + (x3^2-x1^2)*f2 + (x1^2-x2^2)*f3;

    distinct = abs(x1-x2) > eps && abs(x1-x3) > eps && abs(x2-x3) > eps;
    if distinct && isfinite(denom) && abs(denom) > 1e-14 && isfinite(numer)
        xq = numer / denom;
    else
        xq = NaN;
    end

    if ~isfinite(xq)
        step = 2*(rand >= 0.5)-1;
        xq = x1 + step;
    end
    candidate(j) = xq;
end

candidate = max(bounds.lb, min(bounds.ub, candidate));
candidate = problem.projectDecision(candidate);

% Projection can collapse the QIO vertex onto the unchanged elite. Force a
% one-step catalog neighbor so the paid evaluation tests a distinct design
% whenever a neighboring index exists.
if isequal(candidate, bestSol)
    step = 2*(rand >= 0.5)-1;
    candidate(j) = bestSol(j) + step;
    candidate = max(bounds.lb, min(bounds.ub, candidate));
    candidate = problem.projectDecision(candidate);
end
end
