function [bestSol, bestFit, convergence, details] = EnhancedPelicanOptimization(problem, params)
    % Enhanced Pelican Optimization Algorithm (EPOA)
    % Hybrid exploration/exploitation strategy tailored for truss topology problems.

    if nargin < 2
        params = struct();
    end

    if ~isfield(params, 'popSize'), params.popSize = 60; end
    if ~isfield(params, 'maxIter'), params.maxIter = 400; end
    if ~isfield(params, 'penaltyCoef'), params.penaltyCoef = 1e7; end
    if ~isfield(params, 'levyScale'), params.levyScale = 0.02; end

    validateattributes(params.popSize, {'numeric'}, {'scalar', 'integer', '>=', 2}, ...
        mfilename, 'params.popSize');
    validateattributes(params.maxIter, {'numeric'}, {'scalar', 'integer', 'positive'}, ...
        mfilename, 'params.maxIter');
    validateattributes(params.penaltyCoef, {'numeric'}, {'scalar', 'real', 'finite', 'positive'}, ...
        mfilename, 'params.penaltyCoef');
    validateattributes(params.levyScale, {'numeric'}, {'scalar', 'real', 'finite', 'nonnegative'}, ...
        mfilename, 'params.levyScale');

    bounds = problem.getBounds();
    nVar = problem.nVar;

    % Initialize pelicans and include stable upper-bound seed designs.
    pelicans = repmat(bounds.lb, params.popSize, 1) + ...
               rand(params.popSize, nVar) .* repmat(bounds.ub - bounds.lb, params.popSize, 1);

    % Mixed sizing/topology problems use [areas, topology] with exactly
    % 2*nBar variables. Grouped sizing problems (for example the 25-bar
    % benchmark) have fewer variables than members and therefore skip the
    % topology-specific bit flips.
    topologyIdx = [];
    areaIdx = 1:nVar;
    if isprop(problem, 'nBar') && nVar == 2 * problem.nBar
        areaIdx = 1:problem.nBar;
        topologyIdx = (problem.nBar + 1):nVar;
    end

    pelicans(1, areaIdx) = 0.5 * (bounds.lb(areaIdx) + bounds.ub(areaIdx));
    if ~isempty(topologyIdx)
        pelicans(1, topologyIdx) = 1;
    end
    if params.popSize >= 2
        pelicans(2, :) = bounds.ub;
    end

    if ismethod(problem, 'projectDecision')
        for i = 1:params.popSize
            pelicans(i, :) = problem.projectDecision(pelicans(i, :));
        end
    end

    fitness = zeros(params.popSize, 1);
    evaluationCount = 0;
    for i = 1:params.popSize
        [f, g] = problem.evaluate(pelicans(i, :));
        evaluationCount = evaluationCount + 1;
        fitness(i) = f + params.penaltyCoef * g;
    end

    [bestFit, bestIdx] = min(fitness);
    bestSol = pelicans(bestIdx, :);

    convergence = zeros(params.maxIter, 1);

    for iter = 1:params.maxIter
        progress = iter / params.maxIter;

        % Adaptive coefficients
        huntFactor = 2.0 * (1 - progress);       % Exploration fades over time
        diveFactor = 0.2 + 0.8 * progress;       % Exploitation grows over time

        meanPelican = mean(pelicans, 1);

        for i = 1:params.popSize
            Xi = pelicans(i, :);

            if rand < 0.5
                % Phase 1 - Ocean scouting (global exploration)
                r1 = rand(1, nVar);
                r2 = rand(1, nVar);
                candidate = Xi + huntFactor * (r1 .* (bestSol - Xi) + r2 .* (meanPelican - Xi));
            else
                % Phase 2 - Surface strike (local intensification)
                localPerturb = randn(1, nVar) .* (bounds.ub - bounds.lb) * params.levyScale;
                candidate = bestSol + diveFactor * (Xi - bestSol) .* rand(1, nVar) + localPerturb;
            end

            % Topology-aware perturbation of the binary-like variables.
            if ~isempty(topologyIdx)
                flipMask = rand(1, numel(topologyIdx)) < (0.15 * (1 - progress));
                candidate(topologyIdx(flipMask)) = 1 - candidate(topologyIdx(flipMask));
            end

            % Bound correction
            candidate = max(bounds.lb, min(bounds.ub, candidate));
            if ismethod(problem, 'projectDecision')
                candidate = problem.projectDecision(candidate);
            end

            [candF, candG] = problem.evaluate(candidate);
            evaluationCount = evaluationCount + 1;
            candFit = candF + params.penaltyCoef * candG;

            if candFit < fitness(i)
                pelicans(i, :) = candidate;
                fitness(i) = candFit;

                if candFit < bestFit
                    bestFit = candFit;
                    bestSol = candidate;
                end
            end
        end

        convergence(iter) = bestFit;

        if mod(iter, 50) == 0
            fprintf('EPOA - Iter %d: Best Fitness = %.6f\n', iter, bestFit);
        end
    end

    [objective, violation, info] = problem.evaluate(bestSol);
    details.objective = objective;
    details.constraintViolation = violation;
    details.info = info;
    details.evaluationCount = evaluationCount;
    details.isFeasible = info.isFeasible;
    details.parameters = params;
end
